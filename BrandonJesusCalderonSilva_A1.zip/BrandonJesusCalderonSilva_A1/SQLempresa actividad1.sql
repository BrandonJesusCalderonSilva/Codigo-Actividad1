create database empresa_actividad1

use empresa_actividad1

CREATE TABLE Empleados (
Num_Empleado INT PRIMARY KEY IDENTITY(1,1),
Nombre VARCHAR(50) NOT NULL,
Apellido_Paterno VARCHAR(50) NOT NULL,
Apellido_Materno VARCHAR(50) NOT NULL,
Fecha_Nacimiento DATE NOT NULL,
RFC AS (UPPER(SUBSTRING(Nombre,1,2) + SUBSTRING(Apellido_Paterno,1,2) +
SUBSTRING(Apellido_Materno,1,1) +
FORMAT(Fecha_Nacimiento, 'yyMMdd'))),
Centro_Trabajo VARCHAR(50) NOT NULL,
Puesto VARCHAR(50) NOT NULL,
Descripcion_Puesto VARCHAR(100) NOT NULL,
Directivo BIT NOT NULL
)

INSERT INTO Empleados (Nombre, Apellido_Paterno, Apellido_Materno, Fecha_Nacimiento, Centro_Trabajo, Puesto, Descripcion_Puesto, Directivo)
VALUES
('Luis', 'Suarez', 'Silva', '1998-06-11', 'Tiendas Angel Flores Ropa', 'Gerente de Ventas', 'Responsable de la gesti�n del equipo de ventas', 1),
('Brandon', 'Lopez', 'Sanchez', '1995-04-18', 'Tiendas Angel Flores Muebles', 'Ventas', 'Aborda y atiende a todos los clientes aplicando estandares de servicio al cliente', 0),
('Sonia', 'Ramirez', 'Torres', '1989-01-01', 'Tiendas Angel Flores Cajas', 'Cajero', 'Responsable del area de cajas y agilizar el proceso de cobro y abonos', 0),
('Guadalupe', 'Martinez', 'Sanches', '1985-03-22', 'La Primavera Ropa', 'Ventas', 'Realiza acomodos de exhibicion y aborda a todos los clientes ofreciendoles estar a su disposicion', 0),
('Carlos', 'Herrera', 'Lopez', '1999-06-10', 'La primavera muebles', 'Desarrollador de Software', 'Desarrollo y mantenimiento de aplicaciones internas', 0);

CREATE TABLE Centro_de_trabajo (
 Num_centro int primary key identity(1,1),
 Nombre_centro varchar(50) not null,
 Ciudad varchar(50) not null
 )

 INSERT INTO Centro_de_trabajo (Nombre_centro, Ciudad)
 values
 ('Tiendas Angel Flores Ropa', 'Culiacan'),
 ('Tiendas Angel Flores Muebles','Culiacan'),
 ('Tiendas Angel Flores Cajas','Culiacan'),
 ('La Primavera Ropa','Culiacan'),
 ('La Primavera Muebles','Culiacan');

 CREATE TABLE Directivos (
 Nombre varchar(30) primary key,
 Apellido_Paterno varchar(30) not null,
 Apellido_Materno varchar(30) not null,
 Fecha_De_Nacimiento date not null,
 RFC AS (UPPER(SUBSTRING(Nombre,1,2) + SUBSTRING(Apellido_Paterno,1,2) +
SUBSTRING(Apellido_Materno,1,1) +
FORMAT(Fecha_De_Nacimiento, 'yyMMdd'))),
Num_Centro int identity (1,1)
)









INSERT INTO Directivos (Nombre, Apellido_Paterno, Apellido_Materno, Fecha_De_Nacimiento)
VALUES
('Luis', 'Suarez', 'Silva', '1998-06-11'),
('Brandon', 'Lopez', 'Sanchez', '1995-04-18'), 
('Sonia', 'Ramirez', 'Torres', '1989-01-01'),
('Guadalupe', 'Martinez', 'Sanches', '1985-03-22'),
('Carlos', 'Herrera', 'Lopez', '1999-06-10');


